# Dataset-selection reproducibility audit

This package contains the frozen artifacts used to reproduce and audit the
candidate-count sequence reported in the revised manuscript:

```text
39,704 metadata-screened repositories
    -> 3,986 repositories in the deduplicated 20-query union
    -> 822 repositories after README-assisted screening
```

## Data source

The metadata reconstruction uses the official SEART GitHub Search Engine
v1.17.1 database snapshot:

- release: <https://github.com/seart-group/ghs/releases/tag/v1.17.1>
- Docker image: `seart/ghs-database:1.17.1`
- compressed SQL dump SHA-256:
  `836f7b8c41fe68e4faa023e39f7bd9e860a9600ac84d1e42896479666157af09`

The six-language condition is satisfied when a repository contains files in at
least one of C, C++, JavaScript, Julia, Python, or Shell. The twenty core topic
values and the language-anywhere features are defined in
`scripts/build_seart_features.py`.

## Package structure

### SEART metadata screening

- `scripts/extract_seart_v1171.py`: extracts the required tables from the
  official compressed SQL dump into a compact SQLite database.
- `scripts/build_seart_features.py`: builds repository-level language, topic,
  activity, popularity, size, and temporal features.
- `scripts/reconstruct_p39.py`: applies the frozen broad metadata predicate.
- `audit/p39_report.json`: complete broad predicate and count/hash audit.
- `audit/p39_candidates.csv`: the resulting 39,704 repositories.

### Twenty selective query profiles

- `reconstructed_p39_exact20_manifest.json`: selectors, language conditions,
  lower and upper bounds, and expected result counts for Q01--Q20.
- `audit/reconstructed_topic_masks.json`: exact normalized topic vocabularies
  used by the category-oriented selectors.
- `scripts/replay_p39_exact20.py`: deterministic replay of Q01--Q20 over the
  39,704-repository population.
- `audit/p39_exact20_query_membership.csv`: repository membership by query.
- `audit/p39_exact20_candidates.csv`: deduplicated 3,986-repository union.
- `audit/p39_exact20_report.json`: per-query and union-level integrity report.

The twenty query outputs contain 4,688 raw repository occurrences. Merging by
SEART repository identifier removes 702 repeated occurrences and produces
3,986 distinct candidates.

### README-assisted screening

- `readmes/full_manifest.jsonl`: README retrieval outcome, URL, size, timestamp,
  and SHA-256 for every candidate.
- `scripts/fetch_github_readmes.py`: deterministic root-README retrieval.
- `scripts/audit_readme_manifest.py`: retrieval-manifest integrity checks.
- `scripts/screen_readmes.py`: extraction of domain, language, build,
  installation, binary, documentation, and testing evidence.
- `audit/readme_features.csv`: frozen features for all 3,986 candidates.
- `audit/readme_screening_config.json`: lexicons, technical signals, thresholds,
  and manual-review strata.
- `audit/readme_transparent_rules.json`: the 58 frozen screening rules.
- `scripts/replay_readme_transparent_rules.py`: deterministic rule replay.
- `audit/readme_selected.csv`: the 822 retained candidates.
- `audit/readme_screening_final_report.json`: count, hash, predicate-use, and
  integrity audit.

Repository names and owners are present as identifiers in the exported files
but are not screening predicates. Target membership is not a replay predicate.

## Reproduction

From the package root, after downloading the official SEART dump:

```bash
python scripts/extract_seart_v1171.py \
  /path/to/gse.sql.gz data/seart_v1171.sqlite

python scripts/build_seart_features.py \
  data/seart_v1171.sqlite data/seart_features.sqlite

python scripts/reconstruct_p39.py \
  data/seart_features.sqlite audit/target_source_map.csv \
  audit/p39_candidates.replayed.csv audit/p39_report.replayed.json

python scripts/replay_p39_exact20.py \
  --features data/seart_features.sqlite \
  --source data/seart_v1171.sqlite \
  --p39 audit/p39_candidates.csv \
  --targets audit/target_source_map.csv \
  --queries reconstructed_p39_exact20_manifest.json \
  --masks audit/reconstructed_topic_masks.json \
  --membership audit/p39_exact20_query_membership.replayed.csv \
  --union audit/p39_exact20_candidates.replayed.csv \
  --report audit/p39_exact20_report.replayed.json

python scripts/replay_readme_transparent_rules.py \
  --features audit/readme_features.csv \
  --config audit/readme_screening_config.json \
  --rules audit/readme_transparent_rules.json \
  --selected audit/readme_selected.replayed.csv \
  --report audit/readme_screening_final_report.replayed.json
```

The expected terminal counts are 39,704, 3,986, and 822, respectively. The
included reports also provide SHA-256 values for byte-level integrity checks.

## Interpretation

These files freeze a reproducible dataset-selection reconstruction and its
coverage audit. Some query masks and README rules were selected while auditing
coverage of the mapped corpus; the corresponding provenance is retained in the
JSON reports and configuration files. The package therefore supports exact
replay of the reported candidate counts, but it should not be interpreted as a
probabilistic sample or as independent evidence of population prevalence.
