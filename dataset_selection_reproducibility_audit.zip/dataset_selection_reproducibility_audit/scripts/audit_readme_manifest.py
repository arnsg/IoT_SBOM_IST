#!/usr/bin/env python3
"""Audit README downloader input, manifest coverage, and cached payloads.

The audit is read-only with respect to the candidate set, downloader manifest,
and README cache.  Only the JSON report path is written.  A manifest that is
still being appended can be audited safely: an incomplete trailing JSONL line
is ignored and reported as a snapshot warning.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import urllib.parse
from collections import Counter
from datetime import datetime
from pathlib import Path


SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
QUERY_ID_RE = re.compile(r"^Q(?:0[1-9]|1[0-9]|20)$")
FROZEN_CANDIDATE_SHA256 = (
    "cd83e8c66267c6546348a1d7c3ac173793e25967e2b57a00d87d3a0687617141"
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def payload_sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def add_problem(
    problems: list[dict], severity: str, code: str, message: str, **context
) -> None:
    problems.append(
        {
            "severity": severity,
            "code": code,
            "message": message,
            **context,
        }
    )


def load_candidates(
    path: Path, expected_rows: int, expected_targets: int, problems: list[dict]
) -> tuple[list[dict[str, str]], dict[int, dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as handle:
        records = list(csv.DictReader(handle))
    required = {"repo_id", "name", "query_ids", "is_target"}
    headers = set(records[0]) if records else set()
    if not required <= headers:
        add_problem(
            problems,
            "error",
            "candidate_columns_missing",
            "The candidate CSV lacks required columns.",
            missing=sorted(required - headers),
        )

    by_id: dict[int, dict[str, str]] = {}
    names: dict[str, int] = {}
    target_count = 0
    for line_number, record in enumerate(records, 2):
        try:
            repo_id = int(record["repo_id"])
        except (KeyError, TypeError, ValueError):
            add_problem(
                problems,
                "error",
                "candidate_repo_id_invalid",
                "Candidate repo_id is not an integer.",
                csv_line=line_number,
            )
            continue
        if repo_id in by_id:
            add_problem(
                problems,
                "error",
                "candidate_repo_id_duplicate",
                "Candidate repo_id occurs more than once.",
                repo_id=repo_id,
                csv_line=line_number,
            )
        else:
            by_id[repo_id] = record
        name = record.get("name", "")
        if not name or "/" not in name:
            add_problem(
                problems,
                "error",
                "candidate_name_invalid",
                "Candidate name is not a GitHub owner/repository pair.",
                repo_id=repo_id,
                name=name,
            )
        elif name.casefold() in names and names[name.casefold()] != repo_id:
            add_problem(
                problems,
                "error",
                "candidate_name_duplicate",
                "Candidate repository name maps to multiple repo_ids.",
                repo_id=repo_id,
                other_repo_id=names[name.casefold()],
                name=name,
            )
        else:
            names[name.casefold()] = repo_id
        target_raw = record.get("is_target", "")
        if target_raw not in {"0", "1"}:
            add_problem(
                problems,
                "error",
                "candidate_target_invalid",
                "is_target must be either 0 or 1.",
                repo_id=repo_id,
                value=target_raw,
            )
        else:
            target_count += int(target_raw)
        query_ids = record.get("query_ids", "").split("|")
        if not query_ids or any(not QUERY_ID_RE.fullmatch(value) for value in query_ids):
            add_problem(
                problems,
                "error",
                "candidate_query_ids_invalid",
                "query_ids contains an empty or invalid query identifier.",
                repo_id=repo_id,
                value=record.get("query_ids", ""),
            )

    if len(records) != expected_rows:
        add_problem(
            problems,
            "error",
            "candidate_row_count_mismatch",
            "Candidate CSV row count differs from the frozen solution.",
            expected=expected_rows,
            observed=len(records),
        )
    if len(by_id) != expected_rows:
        add_problem(
            problems,
            "error",
            "candidate_unique_count_mismatch",
            "Unique candidate repo_id count differs from the frozen solution.",
            expected=expected_rows,
            observed=len(by_id),
        )
    if target_count != expected_targets:
        add_problem(
            problems,
            "error",
            "candidate_target_count_mismatch",
            "Candidate target count differs from the frozen solution.",
            expected=expected_targets,
            observed=target_count,
        )
    return records, by_id


def manifest_snapshot(path: Path, problems: list[dict]) -> tuple[bytes, list[dict]]:
    if not path.exists():
        add_problem(
            problems,
            "warning",
            "manifest_missing",
            "Manifest does not exist yet; downloader coverage is zero.",
            path=str(path),
        )
        return b"", []
    payload = path.read_bytes()
    complete_payload = payload
    if payload and not payload.endswith(b"\n"):
        boundary = payload.rfind(b"\n")
        complete_payload = payload[: boundary + 1] if boundary >= 0 else b""
        add_problem(
            problems,
            "warning",
            "manifest_trailing_partial_line",
            "The snapshot ended with an incomplete JSONL line; that line was ignored.",
        )
    records: list[dict] = []
    for line_number, raw_line in enumerate(complete_payload.splitlines(), 1):
        if not raw_line.strip():
            add_problem(
                problems,
                "warning",
                "manifest_blank_line",
                "Manifest contains a blank JSONL line.",
                jsonl_line=line_number,
            )
            continue
        try:
            record = json.loads(raw_line)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            add_problem(
                problems,
                "error",
                "manifest_json_invalid",
                "Manifest contains invalid JSON.",
                jsonl_line=line_number,
                detail=str(error),
            )
            continue
        if not isinstance(record, dict):
            add_problem(
                problems,
                "error",
                "manifest_record_not_object",
                "Manifest JSONL record is not an object.",
                jsonl_line=line_number,
            )
            continue
        record["_audit_line"] = line_number
        records.append(record)
    return payload, records


def classify_missing(record: dict) -> str:
    statuses = [attempt.get("status") for attempt in record.get("attempts", [])]
    if statuses and all(status == 404 for status in statuses):
        return "not_found_all_variants"
    if 413 in statuses or record.get("http_status") == 413:
        return "too_large"
    return "request_error"


def audit_manifest(
    records: list[dict],
    candidates: dict[int, dict[str, str]],
    cache_root: Path,
    problems: list[dict],
) -> dict:
    by_id: dict[int, dict] = {}
    cache_paths: dict[Path, int] = {}
    status_counts: Counter[int] = Counter()
    attempt_status_counts: Counter[int] = Counter()
    outcome_counts: Counter[str] = Counter()
    found_target_count = 0
    represented_target_count = 0

    resolved_cache_root = cache_root.resolve()
    for record in records:
        line_number = record.pop("_audit_line")
        try:
            repo_id = int(record.get("repo_id"))
        except (TypeError, ValueError):
            add_problem(
                problems,
                "error",
                "manifest_repo_id_invalid",
                "Manifest repo_id is not an integer.",
                jsonl_line=line_number,
            )
            continue
        if repo_id in by_id:
            add_problem(
                problems,
                "error",
                "manifest_repo_id_duplicate",
                "Manifest contains more than one record for a repo_id.",
                repo_id=repo_id,
                first_line=by_id[repo_id].get("_line"),
                duplicate_line=line_number,
            )
            continue
        record["_line"] = line_number
        by_id[repo_id] = record

        candidate = candidates.get(repo_id)
        if candidate is None:
            add_problem(
                problems,
                "error",
                "manifest_repo_outside_candidates",
                "Manifest repo_id is not in the exclusive 3,986-repository input.",
                repo_id=repo_id,
                jsonl_line=line_number,
            )
        elif record.get("full_name") != candidate["name"]:
            add_problem(
                problems,
                "error",
                "manifest_name_mismatch",
                "Manifest full_name differs from the frozen candidate name.",
                repo_id=repo_id,
                expected=candidate["name"],
                observed=record.get("full_name"),
            )
        elif candidate["is_target"] == "1":
            represented_target_count += 1

        found = record.get("found")
        if type(found) is not bool:
            add_problem(
                problems,
                "error",
                "manifest_found_not_boolean",
                "Manifest found field must be a JSON boolean.",
                repo_id=repo_id,
                observed=found,
            )
            continue
        status = record.get("http_status")
        if not isinstance(status, int):
            add_problem(
                problems,
                "error",
                "manifest_http_status_invalid",
                "Manifest http_status must be an integer.",
                repo_id=repo_id,
                observed=status,
            )
        else:
            status_counts[status] += 1

        attempts = record.get("attempts")
        if not isinstance(attempts, list) or not attempts:
            add_problem(
                problems,
                "error",
                "manifest_attempts_invalid",
                "Manifest attempts must be a non-empty list.",
                repo_id=repo_id,
            )
            attempts = []
        for attempt in attempts:
            if isinstance(attempt, dict) and isinstance(attempt.get("status"), int):
                attempt_status_counts[attempt["status"]] += 1
            else:
                add_problem(
                    problems,
                    "error",
                    "manifest_attempt_invalid",
                    "Manifest attempt lacks an integer status.",
                    repo_id=repo_id,
                )

        fetched_at = record.get("fetched_at_utc", "")
        try:
            parsed = datetime.fromisoformat(fetched_at)
            if parsed.tzinfo is None:
                raise ValueError("timezone missing")
        except (TypeError, ValueError):
            add_problem(
                problems,
                "error",
                "manifest_timestamp_invalid",
                "fetched_at_utc is not a timezone-aware ISO timestamp.",
                repo_id=repo_id,
                observed=fetched_at,
            )

        if found:
            outcome_counts["found"] += 1
            if candidate is not None and candidate["is_target"] == "1":
                found_target_count += 1
            if status != 200:
                add_problem(
                    problems,
                    "error",
                    "found_status_not_200",
                    "A found README must have http_status 200.",
                    repo_id=repo_id,
                    observed=status,
                )
            variant = record.get("variant", "")
            if not variant:
                add_problem(
                    problems,
                    "error",
                    "found_variant_empty",
                    "A found README must record its filename variant.",
                    repo_id=repo_id,
                )
            if not any(
                isinstance(attempt, dict)
                and attempt.get("variant") == variant
                and attempt.get("status") == 200
                for attempt in attempts
            ):
                add_problem(
                    problems,
                    "error",
                    "found_success_attempt_missing",
                    "No successful attempt matches the recorded README variant.",
                    repo_id=repo_id,
                    variant=variant,
                )
            quoted_name = "/".join(
                urllib.parse.quote(part, safe="")
                for part in str(record.get("full_name", "")).split("/", 1)
            )
            expected_url = (
                f"https://raw.githubusercontent.com/{quoted_name}/HEAD/{variant}"
            )
            if record.get("raw_url") != expected_url:
                add_problem(
                    problems,
                    "error",
                    "found_raw_url_mismatch",
                    "raw_url does not match full_name and variant.",
                    repo_id=repo_id,
                    expected=expected_url,
                    observed=record.get("raw_url"),
                )
            cache_value = record.get("cache_file", "")
            cache_path = Path(cache_value)
            resolved_path = cache_path.resolve()
            try:
                resolved_path.relative_to(resolved_cache_root)
            except ValueError:
                add_problem(
                    problems,
                    "error",
                    "cache_path_outside_root",
                    "Recorded README cache path is outside the configured cache root.",
                    repo_id=repo_id,
                    cache_file=cache_value,
                )
            if resolved_path in cache_paths:
                add_problem(
                    problems,
                    "error",
                    "cache_path_duplicate",
                    "Two manifest records refer to the same cache file.",
                    repo_id=repo_id,
                    other_repo_id=cache_paths[resolved_path],
                    cache_file=cache_value,
                )
            else:
                cache_paths[resolved_path] = repo_id
            if not cache_path.is_file():
                add_problem(
                    problems,
                    "error",
                    "cache_file_missing",
                    "Found README cache file does not exist.",
                    repo_id=repo_id,
                    cache_file=cache_value,
                )
            else:
                payload = cache_path.read_bytes()
                observed_size = len(payload)
                observed_hash = payload_sha256(payload)
                if record.get("byte_count") != observed_size:
                    add_problem(
                        problems,
                        "error",
                        "cache_size_mismatch",
                        "Cached README size differs from the manifest.",
                        repo_id=repo_id,
                        expected=record.get("byte_count"),
                        observed=observed_size,
                    )
                expected_hash = record.get("sha256", "")
                if not isinstance(expected_hash, str) or not SHA256_RE.fullmatch(
                    expected_hash
                ):
                    add_problem(
                        problems,
                        "error",
                        "manifest_sha256_invalid",
                        "Manifest SHA-256 is not a lower-case 64-digit hex value.",
                        repo_id=repo_id,
                        observed=expected_hash,
                    )
                elif expected_hash != observed_hash:
                    add_problem(
                        problems,
                        "error",
                        "cache_sha256_mismatch",
                        "Cached README hash differs from the manifest.",
                        repo_id=repo_id,
                        expected=expected_hash,
                        observed=observed_hash,
                    )
        else:
            outcome = classify_missing(record)
            outcome_counts[outcome] += 1
            if record.get("cache_file") or record.get("sha256") or record.get(
                "byte_count"
            ) not in {0, None}:
                add_problem(
                    problems,
                    "error",
                    "missing_record_has_payload_metadata",
                    "A non-found record contains cache, hash, or byte metadata.",
                    repo_id=repo_id,
                )
            if any(
                isinstance(attempt, dict) and attempt.get("status") == 200
                for attempt in attempts
            ):
                add_problem(
                    problems,
                    "error",
                    "missing_record_has_successful_attempt",
                    "A non-found record contains a successful attempt.",
                    repo_id=repo_id,
                )

    represented = set(by_id) & set(candidates)
    pending = set(candidates) - represented
    outside = set(by_id) - set(candidates)
    cache_files = {
        path.resolve()
        for path in cache_root.iterdir()
        if path.is_file()
    } if cache_root.exists() else set()
    orphan_cache_files = sorted(str(path) for path in cache_files - set(cache_paths))
    if orphan_cache_files:
        add_problem(
            problems,
            "warning",
            "cache_files_not_in_snapshot",
            "Cache files exist without a corresponding record in this manifest snapshot; this can be transient while fetching or can indicate another manifest uses the same cache.",
            count=len(orphan_cache_files),
            sample=orphan_cache_files[:20],
        )

    return {
        "manifest_records": len(records),
        "unique_manifest_repo_ids": len(by_id),
        "represented_candidates": len(represented),
        "represented_targets": represented_target_count,
        "found_targets": found_target_count,
        "pending_candidates": len(pending),
        "outside_candidate_repo_ids": len(outside),
        "coverage_percent": round(100.0 * len(represented) / len(candidates), 3)
        if candidates
        else 0.0,
        "outcomes": dict(sorted(outcome_counts.items())),
        "http_statuses": {str(key): value for key, value in sorted(status_counts.items())},
        "attempt_statuses": {
            str(key): value for key, value in sorted(attempt_status_counts.items())
        },
        "verified_cache_files": len(cache_paths),
        "cache_files_not_in_snapshot": len(orphan_cache_files),
        "pending_sample": [
            {"repo_id": repo_id, "name": candidates[repo_id]["name"]}
            for repo_id in sorted(pending)[:20]
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--candidates",
        type=Path,
        default=Path("audit/p39_exact20_candidates.csv"),
    )
    parser.add_argument(
        "--manifest", type=Path, default=Path("readmes/full_manifest.jsonl")
    )
    parser.add_argument("--cache-root", type=Path, default=Path("readmes/full_raw"))
    parser.add_argument(
        "--report", type=Path, default=Path("audit/readme_manifest_audit.json")
    )
    parser.add_argument("--expected-candidates", type=int, default=3986)
    parser.add_argument("--expected-targets", type=int, default=144)
    parser.add_argument(
        "--expected-candidate-sha256", default=FROZEN_CANDIDATE_SHA256
    )
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()

    problems: list[dict] = []
    candidate_digest = file_sha256(args.candidates)
    if (
        args.expected_candidate_sha256
        and candidate_digest != args.expected_candidate_sha256
    ):
        add_problem(
            problems,
            "error",
            "candidate_sha256_mismatch",
            "Candidate CSV differs byte-for-byte from the frozen README input.",
            expected=args.expected_candidate_sha256,
            observed=candidate_digest,
        )
    candidate_records, candidates = load_candidates(
        args.candidates,
        args.expected_candidates,
        args.expected_targets,
        problems,
    )
    snapshot, manifest_records = manifest_snapshot(args.manifest, problems)
    coverage = audit_manifest(manifest_records, candidates, args.cache_root, problems)
    complete = (
        coverage["represented_candidates"] == args.expected_candidates
        and coverage["outside_candidate_repo_ids"] == 0
    )
    if args.require_complete and not complete:
        add_problem(
            problems,
            "error",
            "manifest_incomplete",
            "Manifest does not yet cover every frozen candidate.",
            expected=args.expected_candidates,
            observed=coverage["represented_candidates"],
        )
    error_count = sum(problem["severity"] == "error" for problem in problems)
    warning_count = sum(problem["severity"] == "warning" for problem in problems)
    integrity_status = "passed" if error_count == 0 else "failed"
    coverage_status = "complete" if complete else "partial"
    report = {
        "status": "failed"
        if error_count
        else ("passed" if complete else "in_progress"),
        "integrity_status": integrity_status,
        "coverage_status": coverage_status,
        "candidate_input": {
            "path": str(args.candidates),
            "sha256": candidate_digest,
            "rows": len(candidate_records),
            "unique_repo_ids": len(candidates),
            "targets": sum(
                record.get("is_target") == "1" for record in candidate_records
            ),
        },
        "manifest_snapshot": {
            "path": str(args.manifest),
            "byte_count": len(snapshot),
            "sha256": payload_sha256(snapshot),
        },
        "cache_root": str(args.cache_root),
        "coverage": coverage,
        "problem_counts": {"errors": error_count, "warnings": warning_count},
        "problems": problems,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "integrity_status": integrity_status,
        "coverage_status": coverage_status,
        "represented_candidates": coverage["represented_candidates"],
        "pending_candidates": coverage["pending_candidates"],
        "errors": error_count,
        "warnings": warning_count,
    }, sort_keys=True))
    if error_count:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
