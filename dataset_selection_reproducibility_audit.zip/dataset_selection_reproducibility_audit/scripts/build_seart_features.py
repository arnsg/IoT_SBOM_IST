#!/usr/bin/env python3
"""Build a compact, read-only feature table from the extracted SEART dump."""

from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path


LANGUAGES = ("C", "C++", "JavaScript", "Julia", "Python", "Shell")
CORE_TOPICS = (
    "cyber-physical-systems",
    "embedded-systems",
    "data-analytics",
    "big-data",
    "energy-management",
    "smart-grid",
    "healthcare",
    "e-health",
    "industrial-iot",
    "iiot",
    "iot",
    "internet-of-things",
    "mobile-computing",
    "mobile-application",
    "smart-city",
    "smart-cities",
    "uav",
    "drone",
    "voice-assistant",
    "speech-recognition",
)


def placeholders(values: tuple[object, ...]) -> str:
    return ",".join("?" for _ in values)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"refusing to overwrite {args.output}")

    source = sqlite3.connect(args.source)
    language_ids = {
        name: language_id
        for name, language_id in source.execute(
            f"SELECT name, language_id FROM language WHERE name IN ({placeholders(LANGUAGES)})",
            LANGUAGES,
        )
    }
    topic_ids = tuple(
        row[0]
        for row in source.execute(
            f"SELECT topic_id FROM topic WHERE name IN ({placeholders(CORE_TOPICS)})",
            CORE_TOPICS,
        )
    )
    if set(language_ids) != set(LANGUAGES) or len(topic_ids) != len(CORE_TOPICS):
        raise SystemExit("language or topic dictionary is incomplete")
    source.close()

    connection = sqlite3.connect(args.output)
    connection.execute("ATTACH DATABASE ? AS src", (str(args.source.resolve()),))
    connection.executescript(
        """
        PRAGMA journal_mode=OFF;
        PRAGMA synchronous=OFF;
        PRAGMA temp_store=FILE;
        PRAGMA cache_size=-500000;

        CREATE TABLE language_feature (
            repo_id INTEGER PRIMARY KEY,
            any6 INTEGER NOT NULL,
            has_c INTEGER NOT NULL,
            has_cpp INTEGER NOT NULL,
            has_javascript INTEGER NOT NULL,
            has_julia INTEGER NOT NULL,
            has_python INTEGER NOT NULL,
            has_shell INTEGER NOT NULL
        );
        CREATE TABLE topic_feature (
            repo_id INTEGER PRIMARY KEY,
            topic_count INTEGER NOT NULL,
            core20 INTEGER NOT NULL
        );
        """
    )
    ids = [language_ids[name] for name in LANGUAGES]
    connection.execute(
        f"""
        INSERT INTO language_feature
        SELECT repo_id,
               MAX(language_id IN ({placeholders(tuple(ids))})),
               MAX(language_id = ?), MAX(language_id = ?),
               MAX(language_id = ?), MAX(language_id = ?),
               MAX(language_id = ?), MAX(language_id = ?)
        FROM src.repo_language
        GROUP BY repo_id
        """,
        (*ids, *ids),
    )
    connection.execute(
        f"""
        INSERT INTO topic_feature
        SELECT repo_id, COUNT(*), MAX(topic_id IN ({placeholders(topic_ids)}))
        FROM src.repo_topic
        GROUP BY repo_id
        """,
        topic_ids,
    )
    any6_ids = ",".join(str(value) for value in ids)
    connection.executescript(
        f"""
        CREATE TABLE repo_feature AS
        SELECT r.repo_id, r.name, r.main_language_id, r.is_fork,
               r.commits, r.branches, r.releases,
               r.contributors, r.watchers, r.stars, r.forks, r.size_kb,
               r.created_at, r.total_issues, r.open_issues, r.total_prs,
               r.open_prs, r.last_commit, r.archived, r.locked, r.disabled,
               m.lines_blank, m.lines_code, m.lines_comment, m.lines_total,
               m.lines_non_blank,
               MAX(r.main_language_id IN ({any6_ids}), COALESCE(l.any6, 0)) AS any6,
               MAX(r.main_language_id = {ids[0]}, COALESCE(l.has_c, 0)) AS has_c,
               MAX(r.main_language_id = {ids[1]}, COALESCE(l.has_cpp, 0)) AS has_cpp,
               MAX(r.main_language_id = {ids[2]}, COALESCE(l.has_javascript, 0)) AS has_javascript,
               MAX(r.main_language_id = {ids[3]}, COALESCE(l.has_julia, 0)) AS has_julia,
               MAX(r.main_language_id = {ids[4]}, COALESCE(l.has_python, 0)) AS has_python,
               MAX(r.main_language_id = {ids[5]}, COALESCE(l.has_shell, 0)) AS has_shell,
               COALESCE(t.topic_count, 0) AS topic_count,
               COALESCE(t.core20, 0) AS core20
        FROM src.repo r
        JOIN src.repo_metric m ON m.repo_id = r.repo_id
        LEFT JOIN language_feature l ON l.repo_id = r.repo_id
        LEFT JOIN topic_feature t ON t.repo_id = r.repo_id;

        CREATE UNIQUE INDEX repo_feature_id_idx ON repo_feature(repo_id);
        CREATE UNIQUE INDEX repo_feature_name_idx ON repo_feature(name);
        CREATE INDEX repo_feature_partition_idx
            ON repo_feature(any6, core20, topic_count);
        CREATE INDEX repo_feature_metrics_idx
            ON repo_feature(stars, forks, watchers, contributors, commits,
                            total_prs, total_issues, lines_code, size_kb,
                            last_commit);
        ANALYZE;
        """
    )
    counts = {
        "repo_feature": connection.execute("SELECT COUNT(*) FROM repo_feature").fetchone()[0],
        "language_feature": connection.execute("SELECT COUNT(*) FROM language_feature").fetchone()[0],
        "topic_feature": connection.execute("SELECT COUNT(*) FROM topic_feature").fetchone()[0],
    }
    connection.commit()
    connection.close()
    print(counts)


if __name__ == "__main__":
    main()
