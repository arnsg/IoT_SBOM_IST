#!/usr/bin/env python3
"""Extract the SEART v1.17.1 fields needed by the README audit.

The source is the official MySQL dump.  This script deliberately creates a
small, read-optimised SQLite database without modifying the raw dump.
"""

from __future__ import annotations

import argparse
import gzip
import sqlite3
import time
from pathlib import Path


TABLES = {
    "git_repo",
    "git_repo_language",
    "git_repo_metric_aggregate",
    "git_repo_topic",
    "language",
    "topic",
}


def parse_quoted(text: str, position: int) -> tuple[str, int]:
    assert text[position] == "'"
    position += 1
    output: list[str] = []
    escapes = {
        "0": "\0",
        "b": "\b",
        "n": "\n",
        "r": "\r",
        "t": "\t",
        "Z": "\x1a",
        "\\": "\\",
        "'": "'",
        '"': '"',
    }
    while position < len(text):
        character = text[position]
        if character == "'":
            return "".join(output), position + 1
        if character == "\\" and position + 1 < len(text):
            position += 1
            escaped = text[position]
            output.append(escapes.get(escaped, escaped))
            position += 1
            continue
        output.append(character)
        position += 1
    raise ValueError("unterminated SQL string")


def parse_values(text: str):
    """Yield tuples from the VALUES suffix of a MySQL INSERT statement."""
    position = 0
    length = len(text)
    while position < length:
        while position < length and text[position] in " \t\r\n,;":
            position += 1
        if position >= length:
            return
        if text[position] != "(":
            raise ValueError(f"expected '(' at {position}: {text[position:position+40]!r}")
        position += 1
        row = []
        while True:
            while position < length and text[position] in " \t":
                position += 1
            binary = False
            if text.startswith("_binary", position):
                binary = True
                position += len("_binary")
                while position < length and text[position] in " \t":
                    position += 1
            if position < length and text[position] == "'":
                value, position = parse_quoted(text, position)
                if binary:
                    value = int(any(character != "\0" for character in value))
            else:
                start = position
                while position < length and text[position] not in ",)":
                    position += 1
                token = text[start:position].strip()
                if token == "NULL":
                    value = None
                elif token:
                    value = int(token)
                else:
                    raise ValueError(f"empty SQL token at {position}")
            row.append(value)
            if position >= length:
                raise ValueError("unexpected end of INSERT")
            if text[position] == ",":
                position += 1
                continue
            if text[position] == ")":
                position += 1
                yield tuple(row)
                break
            raise ValueError(f"unexpected separator at {position}: {text[position]!r}")


def initialise(connection: sqlite3.Connection) -> None:
    connection.executescript(
        """
        PRAGMA journal_mode=OFF;
        PRAGMA synchronous=OFF;
        PRAGMA temp_store=MEMORY;
        PRAGMA cache_size=-500000;

        CREATE TABLE repo (
            repo_id INTEGER PRIMARY KEY,
            main_language_id INTEGER NOT NULL,
            name TEXT UNIQUE,
            is_fork INTEGER,
            commits INTEGER,
            branches INTEGER,
            default_branch TEXT,
            releases INTEGER,
            contributors INTEGER,
            watchers INTEGER,
            stars INTEGER,
            forks INTEGER,
            size_kb INTEGER,
            created_at TEXT,
            total_issues INTEGER,
            open_issues INTEGER,
            total_prs INTEGER,
            open_prs INTEGER,
            last_commit TEXT,
            archived INTEGER,
            locked INTEGER,
            disabled INTEGER,
            last_pinged TEXT
        );
        CREATE TABLE repo_language (
            repo_id INTEGER NOT NULL,
            language_id INTEGER NOT NULL,
            bytes INTEGER NOT NULL,
            PRIMARY KEY (repo_id, language_id)
        ) WITHOUT ROWID;
        CREATE TABLE repo_metric (
            repo_id INTEGER PRIMARY KEY,
            lines_blank INTEGER NOT NULL,
            lines_code INTEGER NOT NULL,
            lines_comment INTEGER NOT NULL,
            lines_total INTEGER NOT NULL,
            lines_non_blank INTEGER NOT NULL
        );
        CREATE TABLE repo_topic (
            repo_id INTEGER NOT NULL,
            topic_id INTEGER NOT NULL,
            PRIMARY KEY (repo_id, topic_id)
        ) WITHOUT ROWID;
        CREATE TABLE language (
            language_id INTEGER PRIMARY KEY,
            name TEXT UNIQUE NOT NULL
        );
        CREATE TABLE topic (
            topic_id INTEGER PRIMARY KEY,
            name TEXT UNIQUE NOT NULL
        );
        """
    )


def transformed(table: str, row: tuple):
    if table == "git_repo":
        return (
            row[0], row[1], row[3], row[4], row[5], row[6], row[7], row[8],
            row[9], row[10], row[11], row[12], row[13], row[14], row[18],
            row[19], row[20], row[21], row[22], row[25], row[26], row[27],
            row[28],
        )
    return row


INSERTS = {
    "git_repo": "INSERT INTO repo VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
    "git_repo_language": "INSERT INTO repo_language VALUES (?,?,?)",
    "git_repo_metric_aggregate": "INSERT INTO repo_metric VALUES (?,?,?,?,?,?)",
    "git_repo_topic": "INSERT INTO repo_topic VALUES (?,?)",
    "language": "INSERT INTO language VALUES (?,?)",
    "topic": "INSERT INTO topic VALUES (?,?)",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dump", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"refusing to overwrite existing database: {args.output}")

    started = time.time()
    connection = sqlite3.connect(args.output)
    initialise(connection)
    counts = {table: 0 for table in TABLES}
    prefix = "INSERT INTO `"
    with gzip.open(args.dump, "rt", encoding="utf-8", errors="strict") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.startswith(prefix):
                continue
            table = line[len(prefix):].split("`", 1)[0]
            if table not in TABLES:
                continue
            marker = " VALUES "
            values = line.split(marker, 1)[1]
            batch = []
            for row in parse_values(values):
                batch.append(transformed(table, row))
                if len(batch) >= 10_000:
                    connection.executemany(INSERTS[table], batch)
                    counts[table] += len(batch)
                    batch.clear()
            if batch:
                connection.executemany(INSERTS[table], batch)
                counts[table] += len(batch)
            connection.commit()
            if counts[table] and counts[table] % 100_000 < 10_000:
                print(table, counts[table], "rows", flush=True)

    connection.executescript(
        """
        CREATE INDEX repo_language_language_idx ON repo_language(language_id, repo_id);
        CREATE INDEX repo_topic_topic_idx ON repo_topic(topic_id, repo_id);
        CREATE INDEX repo_last_commit_idx ON repo(last_commit);
        CREATE INDEX repo_metrics_idx ON repo(stars, forks, watchers, contributors, commits);
        ANALYZE;
        """
    )
    connection.commit()
    connection.close()
    print({"counts": counts, "elapsed_seconds": round(time.time() - started, 3)})


if __name__ == "__main__":
    main()
