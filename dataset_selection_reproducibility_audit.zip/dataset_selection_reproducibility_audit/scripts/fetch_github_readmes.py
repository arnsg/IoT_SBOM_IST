#!/usr/bin/env python3
"""Fetch and freeze README files from GitHub's raw-content endpoint.

The script is resumable: each repository receives one JSON manifest record and
one cached byte stream when a README is found.  It deliberately uses a modest
global request rate and never calls the rate-limited GitHub REST API.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path


VARIANTS = (
    "README.md",
    "README.rst",
    "readme.md",
    "Readme.md",
    "README.txt",
    "README.adoc",
    "README.asciidoc",
    "README.markdown",
    "README.mdown",
    "README.rdoc",
    "README",
)
USER_AGENT = "JSEP-SEART-readme-audit/1.0 (research replication audit)"


class RateLimiter:
    def __init__(self, requests_per_second: float) -> None:
        self.interval = 1.0 / requests_per_second
        self.lock = threading.Lock()
        self.next_start = 0.0

    def wait(self) -> None:
        with self.lock:
            now = time.monotonic()
            delay = max(0.0, self.next_start - now)
            self.next_start = max(now, self.next_start) + self.interval
        if delay:
            time.sleep(delay)


def existing_records(path: Path) -> dict[int, dict]:
    records = {}
    if not path.exists():
        return records
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                record = json.loads(line)
                records[int(record["repo_id"])] = record
    return records


def directory_records(path: Path) -> dict[int, dict]:
    """Load durable per-repository records from a checkpoint directory."""
    records: dict[int, dict] = {}
    if not path.exists():
        return records
    for record_path in sorted(path.glob("*.json")):
        record = json.loads(record_path.read_text(encoding="utf-8"))
        records[int(record["repo_id"])] = record
    return records


def write_record_atomic(path: Path, record: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(record, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    os.replace(temporary, path)


def write_manifest_atomic(path: Path, records: dict[int, dict]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as output:
        for repo_id in sorted(records):
            output.write(json.dumps(records[repo_id], ensure_ascii=False) + "\n")
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, path)


def request_bytes(url: str, limiter: RateLimiter, timeout: float) -> tuple[int, bytes, str]:
    last_status = 0
    last_error = ""
    for attempt in range(4):
        limiter.wait()
        request = urllib.request.Request(
            url,
            headers={"User-Agent": USER_AGENT, "Accept": "text/plain,*/*;q=0.1"},
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                content = response.read(2_000_001)
                if len(content) > 2_000_000:
                    return 413, b"", "README exceeds 2,000,000 bytes"
                return response.status, content, ""
        except urllib.error.HTTPError as error:
            last_status = error.code
            last_error = str(error)
            if error.code == 404:
                return error.code, b"", last_error
            if error.code not in {403, 408, 429, 500, 502, 503, 504}:
                return error.code, b"", last_error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            last_error = repr(error)
        time.sleep(min(8.0, 0.5 * 2**attempt))
    return last_status, b"", last_error


def fetch_one(
    record: dict[str, str],
    cache_dir: Path,
    limiter: RateLimiter,
    timeout: float,
    variants: tuple[str, ...],
) -> dict:
    repo_id = int(record["repo_id"])
    full_name = record["name"]
    attempts = []
    result = {
        "repo_id": repo_id,
        "full_name": full_name,
        "fetched_at_utc": datetime.now(timezone.utc).isoformat(),
        "found": False,
        "variant": "",
        "raw_url": "",
        "http_status": 0,
        "byte_count": 0,
        "sha256": "",
        "cache_file": "",
        "attempts": attempts,
    }
    quoted_name = "/".join(urllib.parse.quote(part, safe="") for part in full_name.split("/", 1))
    for variant in variants:
        url = f"https://raw.githubusercontent.com/{quoted_name}/HEAD/{variant}"
        status, content, error = request_bytes(url, limiter, timeout)
        attempts.append({"variant": variant, "status": status, "error": error})
        if status == 200:
            suffix = Path(variant).suffix.lower() or ".txt"
            cache_file = cache_dir / f"{repo_id}{suffix}"
            cache_file.write_bytes(content)
            result.update(
                {
                    "found": True,
                    "variant": variant,
                    "raw_url": url,
                    "http_status": status,
                    "byte_count": len(content),
                    "sha256": hashlib.sha256(content).hexdigest(),
                    "cache_file": str(cache_file),
                }
            )
            break
        if status not in {404}:
            result["http_status"] = status
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("cache_dir", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument(
        "--record-dir",
        type=Path,
        help=(
            "Store one atomic JSON checkpoint per repository and periodically "
            "rebuild the JSONL manifest. This is the safest resumable mode."
        ),
    )
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--requests-per-second", type=float, default=2.0)
    parser.add_argument("--timeout", type=float, default=25.0)
    parser.add_argument("--limit", type=int)
    parser.add_argument(
        "--targets-only",
        action="store_true",
        help="Fetch only rows whose is_target column equals 1.",
    )
    parser.add_argument(
        "--standard-variants-only",
        action="store_true",
        help=(
            "Try only README.md and README.rst. All 143 retrievable target "
            "README files use one of these standard names."
        ),
    )
    parser.add_argument(
        "--nonstandard-variants-only",
        action="store_true",
        help="Try only README filename variants after README.md and README.rst.",
    )
    parser.add_argument(
        "--retry-missing",
        action="store_true",
        help="Retry checkpointed records whose previous outcome was not found.",
    )
    args = parser.parse_args()
    args.cache_dir.mkdir(parents=True, exist_ok=True)
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    if args.record_dir is not None:
        args.record_dir.mkdir(parents=True, exist_ok=True)

    with args.input.open(newline="", encoding="utf-8") as handle:
        records = list(csv.DictReader(handle))
    if args.targets_only:
        records = [record for record in records if record.get("is_target") == "1"]
    if args.limit is not None:
        records = records[: args.limit]
    retry_records: dict[int, dict] = {}
    if args.record_dir is None:
        completed = existing_records(args.manifest)
    else:
        completed = directory_records(args.record_dir)
        # Import any valid records left by an earlier append-only run once.
        for repo_id, record in existing_records(args.manifest).items():
            if repo_id not in completed:
                write_record_atomic(args.record_dir / f"{repo_id}.json", record)
                completed[repo_id] = record
    if args.retry_missing:
        retry_records = {
            repo_id: record
            for repo_id, record in completed.items()
            if not bool(record.get("found"))
        }
        completed = {
            repo_id: record
            for repo_id, record in completed.items()
            if bool(record.get("found"))
        }
    pending = [record for record in records if int(record["repo_id"]) not in completed]
    if args.standard_variants_only and args.nonstandard_variants_only:
        parser.error(
            "--standard-variants-only and --nonstandard-variants-only are mutually exclusive"
        )
    if args.standard_variants_only:
        variants = VARIANTS[:2]
    elif args.nonstandard_variants_only:
        variants = VARIANTS[2:]
    else:
        variants = VARIANTS
    limiter = RateLimiter(args.requests_per_second)
    write_lock = threading.Lock()
    found = sum(bool(record.get("found")) for record in completed.values())
    missing = len(completed) - found

    output_mode = "a" if args.record_dir is None else "w"
    with args.manifest.open(output_mode, encoding="utf-8") as output:
        with ThreadPoolExecutor(max_workers=args.workers) as executor:
            futures = {
                executor.submit(
                    fetch_one,
                    record,
                    args.cache_dir,
                    limiter,
                    args.timeout,
                    variants,
                ): record
                for record in pending
            }
            for index, future in enumerate(as_completed(futures), 1):
                result = future.result()
                previous = retry_records.get(int(result["repo_id"]))
                if previous is not None:
                    result["attempts"] = previous.get("attempts", []) + result.get(
                        "attempts", []
                    )
                with write_lock:
                    if args.record_dir is None:
                        output.write(json.dumps(result, ensure_ascii=False) + "\n")
                        output.flush()
                        os.fsync(output.fileno())
                    else:
                        write_record_atomic(
                            args.record_dir / f"{result['repo_id']}.json", result
                        )
                        completed[int(result["repo_id"])] = result
                if result["found"]:
                    found += 1
                else:
                    missing += 1
                if index % 100 == 0 or index == len(pending):
                    if args.record_dir is not None:
                        write_manifest_atomic(args.manifest, completed)
                    print(
                        json.dumps(
                            {
                                "completed_this_run": index,
                                "pending_this_run": len(pending),
                                "found_total": found,
                                "not_found_or_error_total": missing,
                            }
                        ),
                        flush=True,
                    )


if __name__ == "__main__":
    main()
