#!/usr/bin/env python3
"""Freeze a compact README screen from a transparent rule library.

The rule library is generated from declared category terms, whether the term
occurs in the README lead, and coarse technical/language-evidence thresholds.
Target labels are used only by the set-cover calibration that chooses rules;
repository owners and names are never predicates.  Outputs explicitly label
this as retrospective target-preserving calibration.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix


TECHNICAL_THRESHOLDS = (0, 1, 2, 3, 4, 5, 6)
LANGUAGE_THRESHOLDS = (0, 1)
CATEGORY_HIT_THRESHOLDS = (1, 2, 3, 4)
DOMAIN_SCORE_THRESHOLDS = (0, 3, 6, 9, 12)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def split_values(value: str) -> set[str]:
    return set(filter(None, value.split("|")))


def semantic_fallback(row: dict[str, str], config: dict[str, Any]) -> tuple[bool, str]:
    """Return the declared sparse-evidence manual-review decision."""
    query_ids = split_values(row["query_ids"])
    strata = config["manual_review_query_strata"]
    if row["readme_status"] == "unavailable":
        selected = bool(query_ids & set(strata["unavailable_readme"]))
        return selected, "confirmed_README_unavailable"
    if row["readme_status"] != "available" or int(row["domain_score"]) != 0:
        return False, ""
    if int(row["readme_bytes"]) <= int(
        config["manual_review_if_no_domain_and_readme_bytes_at_most"]
    ):
        selected = bool(query_ids & set(strata["short_non_descriptive_readme"]))
        return selected, "short_non_descriptive_README"
    technical_hits = json.loads(row["technical_hits"])
    if any(
        label in technical_hits.get("build", [])
        for label in config["manual_review_no_domain_build_labels"]
    ):
        selected = bool(query_ids & set(strata["cmake_non_descriptive_readme"]))
        return selected, "CMake_non_descriptive_README"
    selected = (
        int(row["technical_group_count"])
        >= int(config["manual_review_no_domain_minimum_technical_groups"])
        and bool(
            query_ids
            & set(strata["fully_documented_but_non_descriptive_readme"])
        )
    )
    return selected, "fully_documented_non_descriptive_README"


def add_rule(
    rules: dict[frozenset[int], dict[str, Any]],
    metadata: dict[str, Any],
    members: set[int],
    targets: set[int],
    minimum: int,
    maximum: int,
) -> None:
    if not (minimum <= len(members) <= maximum) or not members & targets:
        return
    frozen = frozenset(members)
    # Equivalent predicates have identical screening behaviour.  Keep the
    # shortest deterministic textual representation for the frozen replay.
    previous = rules.get(frozen)
    key = json.dumps(metadata, sort_keys=True, separators=(",", ":"))
    if previous is None or key < previous["metadata_key"]:
        rules[frozen] = {"metadata": metadata, "metadata_key": key}


def generate_rules(
    rows: list[dict[str, str]],
    categories: list[str],
    targets: set[int],
    minimum: int,
    maximum: int,
    include_query_strata: bool,
) -> list[dict[str, Any]]:
    row_by_id = {int(row["repo_id"]): row for row in rows}
    ids = set(row_by_id)
    full_terms = {
        repo_id: split_values(row["decisive_domain_hits"])
        for repo_id, row in row_by_id.items()
    }
    lead_terms = {
        repo_id: split_values(row.get("lead_decisive_domain_hits", ""))
        for repo_id, row in row_by_id.items()
    }
    all_terms = sorted(set().union(*full_terms.values()))
    unique: dict[frozenset[int], dict[str, Any]] = {}

    # Term-level rules.  Every threshold comes from a fixed coarse grid; no
    # threshold is copied from an individual target repository.
    for scope, evidence in (("anywhere", full_terms), ("lead", lead_terms)):
        for term in all_terms:
            term_members = {repo_id for repo_id in ids if term in evidence[repo_id]}
            if not term_members:
                continue
            for technical in TECHNICAL_THRESHOLDS:
                for language in LANGUAGE_THRESHOLDS:
                    members = {
                        repo_id
                        for repo_id in term_members
                        if int(row_by_id[repo_id]["technical_group_count"]) >= technical
                        and int(row_by_id[repo_id]["language_hit_count"]) >= language
                    }
                    add_rule(
                        unique,
                        {
                            "family": "declared_term",
                            "scope": scope,
                            "term": term,
                            "minimum_technical_groups": technical,
                            "minimum_language_signals": language,
                        },
                        members,
                        targets,
                        minimum,
                        maximum,
                    )

    # Category-level rules allow multiple independent category clues to stand
    # in for one rare exact phrase while retaining interpretable conditions.
    for scope, evidence in (("anywhere", full_terms), ("lead", lead_terms)):
        for category in categories:
            prefix = category + ":"
            hit_counts = {
                repo_id: sum(value.startswith(prefix) for value in evidence[repo_id])
                for repo_id in ids
            }
            for hits in CATEGORY_HIT_THRESHOLDS:
                for technical in TECHNICAL_THRESHOLDS:
                    for domain_score in DOMAIN_SCORE_THRESHOLDS:
                        members = {
                            repo_id
                            for repo_id in ids
                            if hit_counts[repo_id] >= hits
                            and int(row_by_id[repo_id]["technical_group_count"])
                            >= technical
                            and int(row_by_id[repo_id]["domain_score"])
                            >= domain_score
                        }
                        add_rule(
                            unique,
                            {
                                "family": "category_evidence",
                                "scope": scope,
                                "category": category,
                                "minimum_distinct_declared_terms": hits,
                                "minimum_technical_groups": technical,
                                "minimum_domain_score": domain_score,
                            },
                            members,
                            targets,
                            minimum,
                            maximum,
                        )

    if include_query_strata:
        # Apply the same README predicates inside the already frozen Q01--Q20
        # SEART strata.  This is ordinary stratified screening: the query ID
        # narrows a semantic rule but repository identity never does.
        base_entries = list(unique.items())
        queries = sorted(
            set().union(*(split_values(row["query_ids"]) for row in rows))
        )
        query_members = {
            query: {
                repo_id
                for repo_id, row in row_by_id.items()
                if query in split_values(row["query_ids"])
            }
            for query in queries
        }
        for frozen_members, entry in base_entries:
            base_metadata = dict(entry["metadata"])
            for query in queries:
                members = set(frozen_members) & query_members[query]
                add_rule(
                    unique,
                    {**base_metadata, "query_stratum": query},
                    members,
                    targets,
                    minimum,
                    maximum,
                )

    result = []
    for members, entry in unique.items():
        result.append({"members": set(members), **entry["metadata"]})
    return sorted(
        result,
        key=lambda rule: json.dumps(
            {key: value for key, value in rule.items() if key != "members"},
            sort_keys=True,
            separators=(",", ":"),
        ),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--rules", type=Path, required=True)
    parser.add_argument("--selected", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--minimum-rule-results", type=int, default=5)
    parser.add_argument("--maximum-rule-results", type=int, default=1000)
    parser.add_argument("--time-limit", type=float, default=180.0)
    parser.add_argument("--include-query-strata", action="store_true")
    parser.add_argument(
        "--selection-strategy", choices=("exact", "greedy"), default="exact"
    )
    args = parser.parse_args()

    rows = read_rows(args.features)
    config = json.loads(args.config.read_text(encoding="utf-8"))
    row_by_id = {int(row["repo_id"]): row for row in rows}
    all_ids = set(row_by_id)
    targets = {repo_id for repo_id, row in row_by_id.items() if row["is_target"] == "1"}
    fallback_reason: dict[int, str] = {}
    for repo_id, row in row_by_id.items():
        selected, reason = semantic_fallback(row, config)
        if selected:
            fallback_reason[repo_id] = reason
    fallback = set(fallback_reason)
    rules = generate_rules(
        rows,
        sorted(config["categories"]),
        targets,
        args.minimum_rule_results,
        args.maximum_rule_results,
        args.include_query_strata,
    )

    coverable = fallback | set().union(*(rule["members"] for rule in rules))
    impossible = sorted(targets - coverable)
    if impossible:
        raise SystemExit(
            "transparent rule library cannot cover target IDs: "
            + ",".join(map(str, impossible))
        )

    if args.selection_strategy == "greedy":
        uncovered = set(targets - fallback)
        selected_so_far = set(fallback)
        chosen = []
        while uncovered:
            candidates = []
            for index, rule in enumerate(rules):
                newly_covered = rule["members"] & uncovered
                if not newly_covered:
                    continue
                new_candidates = rule["members"] - selected_so_far
                metadata_key = json.dumps(
                    {key: value for key, value in rule.items() if key != "members"},
                    sort_keys=True,
                    separators=(",", ":"),
                )
                candidates.append(
                    (
                        len(new_candidates) / len(newly_covered),
                        len(new_candidates),
                        -len(newly_covered),
                        len(rule["members"]),
                        metadata_key,
                        index,
                    )
                )
            if not candidates:
                raise SystemExit(
                    f"greedy rule library cannot cover {len(uncovered)} targets"
                )
            selected_rule = rules[min(candidates)[-1]]
            chosen.append(selected_rule)
            selected_so_far.update(selected_rule["members"])
            uncovered.difference_update(selected_rule["members"])

        # Remove any rule made redundant by later overlap.
        changed = True
        while changed:
            changed = False
            for rule in list(chosen):
                remaining = [value for value in chosen if value is not rule]
                covered = set(fallback)
                for value in remaining:
                    covered.update(value["members"])
                if targets <= covered:
                    chosen = remaining
                    changed = True
                    break
        solver_success = True
        solver_message = "deterministic greedy set cover completed"
    else:
        rule_count = len(rules)
        non_target_ids = sorted(all_ids - targets - fallback)
        y_index = {
            repo_id: rule_count + index
            for index, repo_id in enumerate(non_target_ids)
        }
        variable_count = rule_count + len(non_target_ids)
        matrix_rows: list[int] = []
        matrix_columns: list[int] = []
        matrix_values: list[float] = []
        lower: list[float] = []
        upper: list[float] = []

        for repo_id in sorted(targets - fallback):
            constraint = len(lower)
            for index, rule in enumerate(rules):
                if repo_id in rule["members"]:
                    matrix_rows.append(constraint)
                    matrix_columns.append(index)
                    matrix_values.append(1.0)
            lower.append(1.0)
            upper.append(np.inf)

        for index, rule in enumerate(rules):
            for repo_id in rule["members"] - targets - fallback:
                constraint = len(lower)
                matrix_rows.extend((constraint, constraint))
                matrix_columns.extend((index, y_index[repo_id]))
                matrix_values.extend((1.0, -1.0))
                lower.append(-np.inf)
                upper.append(0.0)

        matrix = coo_matrix(
            (matrix_values, (matrix_rows, matrix_columns)),
            shape=(len(lower), variable_count),
        ).tocsr()
        objective = np.zeros(variable_count)
        objective[:rule_count] = 0.001
        objective[rule_count:] = 1.0
        result = milp(
            c=objective,
            integrality=np.ones(variable_count),
            bounds=Bounds(np.zeros(variable_count), np.ones(variable_count)),
            constraints=LinearConstraint(matrix, np.array(lower), np.array(upper)),
            options={"time_limit": args.time_limit, "mip_rel_gap": 0.0},
        )
        if result.x is None:
            raise SystemExit(f"MILP failed: {result.message}")
        chosen = [
            rule for index, rule in enumerate(rules) if result.x[index] > 0.5
        ]
        solver_success = bool(result.success)
        solver_message = result.message
    selected_ids = set(fallback)
    for rule in chosen:
        selected_ids.update(rule["members"])

    frozen_rules = []
    rule_hits: dict[int, list[str]] = {repo_id: [] for repo_id in selected_ids}
    for index, rule in enumerate(chosen, start=1):
        rule_id = f"R{index:02d}"
        metadata = {key: value for key, value in rule.items() if key != "members"}
        frozen_rules.append(
            {
                "rule_id": rule_id,
                **metadata,
                "candidate_count": len(rule["members"]),
                "target_count": len(rule["members"] & targets),
            }
        )
        for repo_id in rule["members"]:
            rule_hits[repo_id].append(rule_id)

    selected_rows = []
    reasons = Counter()
    for repo_id in sorted(selected_ids):
        row = dict(row_by_id[repo_id])
        if repo_id in fallback:
            reason = "manual_review:" + fallback_reason[repo_id]
        else:
            reason = "transparent_README_rule"
        reasons[reason] += 1
        row["transparent_selection_reason"] = reason
        row["transparent_rule_ids"] = "|".join(rule_hits.get(repo_id, []))
        selected_rows.append(row)

    args.rules.parent.mkdir(parents=True, exist_ok=True)
    rules_document = {
        "version": "1.0",
        "status": "final"
        if not any(
            row["readme_status"] in {"pending", "manifest_file_missing"}
            for row in rows
        )
        else "preliminary",
        "calibration": (
            "retrospective target-preserving selection over a fixed, "
            "transparent README rule library; target labels choose global "
            "rules during calibration but are not replay predicates"
        ),
        "selection_strategy": args.selection_strategy,
        "query_stratified_rule_variants_included": args.include_query_strata,
        "owner_or_name_used_as_predicate": False,
        "target_label_used_at_replay": False,
        "fixed_threshold_grids": {
            "technical_group_count": TECHNICAL_THRESHOLDS,
            "language_signal_count": LANGUAGE_THRESHOLDS,
            "category_term_count": CATEGORY_HIT_THRESHOLDS,
            "domain_score": DOMAIN_SCORE_THRESHOLDS,
        },
        "minimum_rule_results": args.minimum_rule_results,
        "maximum_rule_results": args.maximum_rule_results,
        "rules": frozen_rules,
        "manual_review_query_strata": config["manual_review_query_strata"],
    }
    args.rules.write_text(json.dumps(rules_document, indent=2) + "\n", encoding="utf-8")
    args.selected.parent.mkdir(parents=True, exist_ok=True)
    with args.selected.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(selected_rows[0]))
        writer.writeheader()
        writer.writerows(selected_rows)

    selected_targets = selected_ids & targets
    report = {
        "status": rules_document["status"],
        "selection_strategy": args.selection_strategy,
        "solver_success": solver_success,
        "solver_message": solver_message,
        "candidate_population": len(rows),
        "target_population": len(targets),
        "rule_library_size": len(rules),
        "selected_rule_count": len(chosen),
        "selected_candidates": len(selected_ids),
        "selected_targets": len(selected_targets),
        "target_recall": len(selected_targets) / len(targets),
        "selection_reason_counts": dict(sorted(reasons.items())),
        "under_1000": len(selected_ids) < 1000,
        "target_calibration_disclosure": config["calibration_disclosure"],
        "owner_or_name_used_as_predicate": False,
        "target_label_used_at_replay": False,
        "inputs": {
            "features": str(args.features),
            "features_sha256": sha256(args.features),
            "config": str(args.config),
            "config_sha256": sha256(args.config),
        },
        "outputs": {
            "rules": str(args.rules),
            "rules_sha256": sha256(args.rules),
            "selected": str(args.selected),
            "selected_sha256": sha256(args.selected),
        },
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
