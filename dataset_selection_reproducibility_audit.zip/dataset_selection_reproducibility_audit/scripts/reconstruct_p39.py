#!/usr/bin/env python3
"""Reconstruct the fixed 39,704-repository SEART candidate population."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from pathlib import Path


P0_CORE = """
any6 = 1 AND core20 = 1
AND stars >= 50 AND forks >= 10 AND watchers >= 10
AND contributors >= 10 AND commits >= 100 AND total_prs >= 25
AND lines_code >= 25000 AND size_kb >= 5000
AND last_commit >= '2020-01-01'
"""

P0_ZERO = """
any6 = 1 AND topic_count = 0
AND stars >= 25 AND forks >= 5 AND watchers >= 10
AND contributors >= 2 AND commits >= 30 AND total_prs >= 10
AND lines_code >= 3000 AND size_kb >= 1000
AND last_commit >= '2014-01-01'
"""

P0_OTHER = """
any6 = 1 AND core20 = 0 AND topic_count > 0
AND stars >= 15 AND forks >= 5 AND watchers >= 10
AND contributors >= 10 AND commits >= 250
AND lines_code >= 10000 AND size_kb >= 2500
AND last_commit >= '2023-01-01'
"""

COMPACT_ZERO = """
(
  (stars >= 100 AND forks >= 50 AND watchers >= 25)
  OR
  (lines_code >= 50000 AND commits >= 500 AND contributors >= 10)
)
"""

COMPACT_OTHER = """
(
  (topic_count BETWEEN 1 AND 2 AND lines_code >= 50000
   AND size_kb >= 25000 AND commits >= 1000 AND contributors >= 25
   AND last_commit >= '2024-01-01')
  OR
  (topic_count BETWEEN 3 AND 4 AND commits >= 1000
   AND contributors >= 25 AND last_commit >= '2024-01-01')
  OR
  (topic_count BETWEEN 5 AND 9 AND total_prs >= 100)
  OR
  (topic_count >= 10 AND lines_code >= 25000
   AND size_kb >= 25000 AND commits >= 500)
)
"""

P39 = f"(({P0_CORE}) OR (({P0_ZERO}) AND ({COMPACT_ZERO})) OR (({P0_OTHER}) AND ({COMPACT_OTHER})))"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("features", type=Path)
    parser.add_argument("target_map", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("report", type=Path)
    args = parser.parse_args()

    with args.target_map.open(newline="", encoding="utf-8") as handle:
        target_ids = {
            int(row["seart_repo_id"])
            for row in csv.DictReader(handle)
            if row["seart_repo_id"]
        }

    connection = sqlite3.connect(args.features)
    columns = [row[1] for row in connection.execute("PRAGMA table_info(repo_feature)")]
    rows = connection.execute(
        f"SELECT {','.join(columns)} FROM repo_feature WHERE {P39} ORDER BY repo_id"
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    selected_targets = set()
    count = 0
    branch_counts = {"core": 0, "zero": 0, "other": 0}
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([*columns, "is_target"])
        for row in rows:
            record = dict(zip(columns, row))
            repo_id = record["repo_id"]
            is_target = int(repo_id in target_ids)
            if is_target:
                selected_targets.add(repo_id)
            branch = "core" if record["core20"] else ("zero" if record["topic_count"] == 0 else "other")
            branch_counts[branch] += 1
            writer.writerow([*row, is_target])
            count += 1
    connection.close()

    report = {
        "population": "P39",
        "candidate_count": count,
        "target_count": len(selected_targets),
        "indexed_target_count": len(target_ids),
        "branch_candidate_counts": branch_counts,
        "p0_branch_expected_counts": {"core": 432, "zero": 48739, "other": 25227},
        "predicate": P39,
        "output_sha256": digest(args.output),
    }
    if count != 39704 or len(selected_targets) != 144:
        raise SystemExit(f"reconstruction mismatch: {report}")
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
