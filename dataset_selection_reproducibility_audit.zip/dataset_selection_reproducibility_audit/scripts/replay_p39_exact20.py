#!/usr/bin/env python3
"""Replay the calibrated P39 20-query reconstruction without modifying SEART."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
from collections import defaultdict
from pathlib import Path


COLUMN_SQL = {
    "stars": "f.stars",
    "forks": "f.forks",
    "watchers": "f.watchers",
    "contributors": "f.contributors",
    "commits": "f.commits",
    "total_prs": "f.total_prs",
    "total_issues": "f.total_issues",
    "lines_code": "f.lines_code",
    "size_kb": "f.size_kb",
    "last_year": "CAST(SUBSTR(f.last_commit, 1, 4) AS INTEGER)",
}

LANGUAGE_SQL = {
    None: "1",
    "ANY6": "f.any6 = 1",
    "C++": "f.has_cpp = 1",
    "JavaScript": "f.has_javascript = 1",
    "Shell": "f.has_shell = 1",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def target_ids(path: Path) -> tuple[set[int], dict[int, str]]:
    ids: set[int] = set()
    names: dict[int, str] = {}
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            if row["in_seart_v1_17_1"] != "1":
                continue
            repo_id = int(row["seart_repo_id"])
            ids.add(repo_id)
            names[repo_id] = row["seart_name"]
    return ids, names


def p39_ids(path: Path) -> set[int]:
    with path.open(newline="", encoding="utf-8") as handle:
        return {int(row["repo_id"]) for row in csv.DictReader(handle)}


def topic_exists(topics: list[str], *, negated: bool = False) -> tuple[str, list[str]]:
    placeholders = ",".join("?" for _ in topics)
    prefix = "NOT EXISTS" if negated else "EXISTS"
    sql = f"""{prefix} (
        SELECT 1
        FROM source.repo_topic rt
        JOIN source.topic t USING(topic_id)
        WHERE rt.repo_id = f.repo_id
          AND LOWER(TRIM(t.name)) IN ({placeholders})
    )"""
    return sql, [topic.strip().lower() for topic in topics]


def selector_sql(query: dict, masks: dict) -> tuple[list[str], list[object]]:
    query_id = query["id"]
    clauses: list[str] = []
    parameters: list[object] = []
    if query_id in masks["query_masks"]:
        mask = masks["query_masks"][query_id]
        clause, values = topic_exists(mask["topics"])
        clauses.append(clause)
        parameters.extend(values)
        if mask["mode"] == "extended_domain_noncore":
            excluded = masks["query_masks"][mask["exclude_topics_from"]]["topics"]
            clause, values = topic_exists(excluded, negated=True)
            clauses.append(clause)
            parameters.extend(values)
        return clauses, parameters

    selector = query["selector"]
    mode = selector.get("topic_mode")
    if mode == "exact_topic":
        clause, values = topic_exists([selector["topic_value"]])
        clauses.append(clause)
        parameters.extend(values)
    elif mode == "zero" or selector.get("topic_count") == 0:
        clauses.append("f.topic_count = 0")
    elif mode == "other_1_2":
        clauses.append("f.core20 = 0 AND f.topic_count BETWEEN 1 AND 2")
    elif mode == "other_3_4":
        clauses.append("f.core20 = 0 AND f.topic_count BETWEEN 3 AND 4")
    elif mode == "other_10plus":
        clauses.append("f.core20 = 0 AND f.topic_count >= 10")
    else:
        raise ValueError(f"unresolved selector for {query_id}: {selector}")
    return clauses, parameters


def query_membership(connection: sqlite3.Connection, query: dict, masks: dict):
    clauses, parameters = selector_sql(query, masks)
    clauses.append(LANGUAGE_SQL[query["language_mode"]])
    for name, value in query["lower_bounds"].items():
        clauses.append(f"{COLUMN_SQL[name]} >= ?")
        parameters.append(value)
    for name, value in query["upper_bounds"].items():
        clauses.append(f"{COLUMN_SQL[name]} <= ?")
        parameters.append(value)
    sql = f"""SELECT f.repo_id, f.name
              FROM repo_feature f
              JOIN p39 p USING(repo_id)
              WHERE {' AND '.join(f'({clause})' for clause in clauses)}
              ORDER BY f.repo_id"""
    return connection.execute(sql, parameters).fetchall()


def write_csv(path: Path, header: list[str], rows) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", type=Path, default=Path("data/seart_features.sqlite"))
    parser.add_argument("--source", type=Path, default=Path("data/seart_v1171.sqlite"))
    parser.add_argument("--p39", type=Path, default=Path("audit/p39_candidates.csv"))
    parser.add_argument("--targets", type=Path, default=Path("audit/target_source_map.csv"))
    parser.add_argument("--queries", type=Path, default=Path("reconstructed_p39_exact20_manifest.json"))
    parser.add_argument("--masks", type=Path, default=Path("audit/reconstructed_topic_masks.json"))
    parser.add_argument("--membership", type=Path, default=Path("audit/p39_exact20_query_membership.csv"))
    parser.add_argument("--union", dest="union_path", type=Path, default=Path("audit/p39_exact20_candidates.csv"))
    parser.add_argument("--report", type=Path, default=Path("audit/p39_exact20_report.json"))
    args = parser.parse_args()

    manifest = json.loads(args.queries.read_text(encoding="utf-8"))
    masks = json.loads(args.masks.read_text(encoding="utf-8"))
    targets, target_names = target_ids(args.targets)
    population = p39_ids(args.p39)
    indexed_targets = targets & population
    excluded_targets = targets - population

    connection = sqlite3.connect(f"file:{args.features.resolve()}?mode=ro", uri=True)
    connection.execute("ATTACH DATABASE ? AS source", (f"file:{args.source.resolve()}?mode=ro",))
    connection.execute("CREATE TEMP TABLE p39(repo_id INTEGER PRIMARY KEY)")
    connection.executemany("INSERT INTO p39 VALUES (?)", ((repo_id,) for repo_id in population))

    memberships: dict[str, set[int]] = {}
    repo_names: dict[int, str] = {}
    observed_queries: list[dict] = []
    errors: list[str] = []
    membership_rows = []
    for query in manifest["queries"]:
        rows = query_membership(connection, query, masks)
        members = {repo_id for repo_id, _ in rows}
        memberships[query["id"]] = members
        repo_names.update(rows)
        target_members = members & indexed_targets
        observed = {
            "id": query["id"],
            "expected_candidates": query["candidate_count"],
            "observed_candidates": len(members),
            "expected_target_occurrences": query["target_occurrence_count"],
            "observed_target_occurrences": len(target_members),
        }
        observed_queries.append(observed)
        if observed["expected_candidates"] != observed["observed_candidates"]:
            errors.append(f"{query['id']} candidate mismatch")
        if observed["expected_target_occurrences"] != observed["observed_target_occurrences"]:
            errors.append(f"{query['id']} target mismatch")
        for repo_id, name in rows:
            membership_rows.append((query["id"], repo_id, name, int(repo_id in indexed_targets)))

    union = set().union(*memberships.values())
    target_union = union & indexed_targets
    raw_candidates = sum(len(members) for members in memberships.values())
    raw_targets = sum(len(members & indexed_targets) for members in memberships.values())
    expected = masks["expected_solution"]
    summary = {
        "raw_candidate_occurrences": raw_candidates,
        "distinct_candidate_union": len(union),
        "raw_target_occurrences": raw_targets,
        "distinct_targets_covered": len(target_union),
    }
    for key, observed in summary.items():
        if expected[key] != observed:
            errors.append(f"solution mismatch for {key}: expected {expected[key]}, observed {observed}")

    write_csv(
        args.membership,
        ["query_id", "repo_id", "name", "is_target"],
        sorted(membership_rows),
    )
    query_ids_by_repo = defaultdict(list)
    for query_id, members in memberships.items():
        for repo_id in members:
            query_ids_by_repo[repo_id].append(query_id)
    union_rows = [
        (
            repo_id,
            repo_names[repo_id],
            "|".join(sorted(query_ids_by_repo[repo_id])),
            int(repo_id in indexed_targets),
        )
        for repo_id in sorted(union)
    ]
    write_csv(args.union_path, ["repo_id", "name", "query_ids", "is_target"], union_rows)

    report = {
        "status": "passed" if not errors else "failed",
        "reconstruction_status": masks["status"],
        "p39_candidates": len(population),
        "indexed_targets": len(targets),
        "p39_targets": len(indexed_targets),
        "covered_p39_targets": len(target_union),
        "excluded_indexed_targets": [
            {"repo_id": repo_id, "name": target_names[repo_id]}
            for repo_id in sorted(excluded_targets)
        ],
        "queries": observed_queries,
        "expected_solution": expected,
        "observed_solution": summary,
        "errors": errors,
        "inputs": {
            "features": str(args.features),
            "source": str(args.source),
            "p39": str(args.p39),
            "targets": str(args.targets),
            "queries": str(args.queries),
            "masks": str(args.masks),
        },
        "outputs": {
            "membership": str(args.membership),
            "membership_sha256": sha256(args.membership),
            "union": str(args.union_path),
            "union_sha256": sha256(args.union_path),
        },
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    connection.close()
    if errors:
        raise SystemExit("; ".join(errors))
    print(json.dumps(report["observed_solution"], sort_keys=True))


if __name__ == "__main__":
    main()
