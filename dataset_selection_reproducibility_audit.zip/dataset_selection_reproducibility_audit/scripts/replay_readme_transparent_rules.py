#!/usr/bin/env python3
"""Replay frozen transparent README rules without target/name predicates."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def split_values(value: str) -> set[str]:
    return set(filter(None, value.split("|")))


def fallback(row: dict[str, str], config: dict[str, Any]) -> tuple[bool, str]:
    query_ids = split_values(row["query_ids"])
    strata = config["manual_review_query_strata"]
    if row["readme_status"] == "unavailable":
        return (
            bool(query_ids & set(strata["unavailable_readme"])),
            "confirmed_README_unavailable",
        )
    if row["readme_status"] != "available" or int(row["domain_score"]) != 0:
        return False, ""
    if int(row["readme_bytes"]) <= int(
        config["manual_review_if_no_domain_and_readme_bytes_at_most"]
    ):
        return (
            bool(query_ids & set(strata["short_non_descriptive_readme"])),
            "short_non_descriptive_README",
        )
    technical_hits = json.loads(row["technical_hits"])
    if any(
        label in technical_hits.get("build", [])
        for label in config["manual_review_no_domain_build_labels"]
    ):
        return (
            bool(query_ids & set(strata["cmake_non_descriptive_readme"])),
            "CMake_non_descriptive_README",
        )
    return (
        int(row["technical_group_count"])
        >= int(config["manual_review_no_domain_minimum_technical_groups"])
        and bool(
            query_ids
            & set(strata["fully_documented_but_non_descriptive_readme"])
        ),
        "fully_documented_non_descriptive_README",
    )


def matches_rule(row: dict[str, str], rule: dict[str, Any]) -> bool:
    if rule.get("query_stratum") not in (None, "") and rule[
        "query_stratum"
    ] not in split_values(row["query_ids"]):
        return False
    if int(row["technical_group_count"]) < int(
        rule["minimum_technical_groups"]
    ):
        return False
    scope = rule["scope"]
    values = split_values(
        row[
            "lead_decisive_domain_hits"
            if scope == "lead"
            else "decisive_domain_hits"
        ]
    )
    if rule["family"] == "declared_term":
        return (
            rule["term"] in values
            and int(row["language_hit_count"])
            >= int(rule["minimum_language_signals"])
        )
    if rule["family"] == "category_evidence":
        prefix = rule["category"] + ":"
        return (
            sum(value.startswith(prefix) for value in values)
            >= int(rule["minimum_distinct_declared_terms"])
            and int(row["domain_score"]) >= int(rule["minimum_domain_score"])
        )
    raise ValueError(f"unknown rule family: {rule['family']}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--rules", type=Path, required=True)
    parser.add_argument("--selected", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    with args.features.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    config = json.loads(args.config.read_text(encoding="utf-8"))
    rules_document = json.loads(args.rules.read_text(encoding="utf-8"))
    rules = rules_document["rules"]
    selected_rows = []
    reasons = Counter()
    for row in rows:
        manual, manual_reason = fallback(row, config)
        hits = [rule["rule_id"] for rule in rules if matches_rule(row, rule)]
        if manual:
            reason = "manual_review:" + manual_reason
        elif hits:
            reason = "transparent_README_rule"
        else:
            continue
        output = dict(row)
        output["transparent_selection_reason"] = reason
        output["transparent_rule_ids"] = "|".join(hits)
        selected_rows.append(output)
        reasons[reason] += 1

    args.selected.parent.mkdir(parents=True, exist_ok=True)
    with args.selected.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(selected_rows[0]))
        writer.writeheader()
        writer.writerows(selected_rows)

    # Target labels are read after selection only to audit recall; neither the
    # predicate loop above nor the frozen rule document depends on them.
    target_count = sum(row["is_target"] == "1" for row in rows)
    selected_target_count = sum(row["is_target"] == "1" for row in selected_rows)
    report = {
        "status": rules_document["status"],
        "candidate_population": len(rows),
        "selected_candidates": len(selected_rows),
        "target_population_audit_only": target_count,
        "selected_targets_audit_only": selected_target_count,
        "target_recall_audit_only": selected_target_count / target_count,
        "selection_reason_counts": dict(sorted(reasons.items())),
        "under_1000": len(selected_rows) < 1000,
        "owner_or_name_used_as_predicate": False,
        "target_label_used_as_replay_predicate": False,
        "inputs": {
            "features": str(args.features),
            "features_sha256": sha256(args.features),
            "config": str(args.config),
            "config_sha256": sha256(args.config),
            "rules": str(args.rules),
            "rules_sha256": sha256(args.rules),
        },
        "outputs": {
            "selected": str(args.selected),
            "selected_sha256": sha256(args.selected),
        },
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
