#!/usr/bin/env python3
"""Deterministic semantic/technical screening of a frozen README collection.

Repository owner, repository name, query id, and target membership are never
included in the scored text.  Target labels may optionally calibrate one global
threshold; this is reported explicitly and never acts as a row-specific rule.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_jsonl(paths: list[Path] | None) -> dict[int, dict[str, Any]]:
    records: dict[int, dict[str, Any]] = {}
    if not paths:
        return records
    for path in paths:
        if not path.exists():
            continue
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                record = json.loads(line)
                records[int(record["repo_id"])] = record
    return records


def load_record_directories(paths: list[Path] | None) -> dict[int, dict[str, Any]]:
    records: dict[int, dict[str, Any]] = {}
    if not paths:
        return records
    for directory in paths:
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.json")):
            record = json.loads(path.read_text(encoding="utf-8"))
            records[int(record["repo_id"])] = record
    return records


def load_descriptions(path: Path | None) -> dict[int, str]:
    descriptions: dict[int, str] = {}
    if path is None:
        return descriptions
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            descriptions[int(row["repo_id"])] = row.get("description", "")
    return descriptions


def readme_paths(directories: list[Path]) -> dict[int, Path]:
    paths: dict[int, Path] = {}
    for directory in directories:
        if not directory.exists():
            continue
        for path in sorted(directory.iterdir()):
            if not path.is_file():
                continue
            try:
                repo_id = int(path.name.split(".", 1)[0])
            except ValueError:
                continue
            paths[repo_id] = path
    return paths


def normalize_markdown(value: str) -> str:
    value = html.unescape(value)
    value = re.sub(r"```.*?```", " ", value, flags=re.DOTALL)
    value = re.sub(r"`([^`]*)`", r" \1 ", value)
    # Strip tags before bare URLs: otherwise an href without whitespace can
    # make the URL expression swallow the visible anchor text and closing tag.
    value = re.sub(r"<[^>]+>", " ", value)
    value = re.sub(r"https?://\S+", " ", value)
    value = re.sub(r"[\[\]#*_>|~]", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip().lower()


def compile_map(values: dict[str, str]) -> dict[str, re.Pattern[str]]:
    return {label: re.compile(pattern, re.IGNORECASE) for label, pattern in values.items()}


def matched(compiled: dict[str, re.Pattern[str]], text: str) -> list[str]:
    return [label for label, pattern in compiled.items() if pattern.search(text)]


def feature_row(
    candidate: dict[str, str],
    path: Path | None,
    manifest_record: dict[str, Any] | None,
    description: str,
    config: dict[str, Any],
    category_patterns: dict[str, dict[str, dict[str, re.Pattern[str]]]],
    technical_patterns: dict[str, dict[str, re.Pattern[str]]],
    language_patterns: dict[str, re.Pattern[str]],
    decisive_patterns: dict[str, dict[str, re.Pattern[str]]],
) -> dict[str, Any]:
    repo_id = int(candidate["repo_id"])
    if path is not None:
        status = "available"
        readme = path.read_bytes().decode("utf-8", errors="replace")
    elif manifest_record is not None:
        status = "unavailable" if not manifest_record.get("found") else "manifest_file_missing"
        readme = ""
    else:
        status = "pending"
        readme = ""

    scored_text = normalize_markdown(f"{description}\n{readme}")
    lead_text = scored_text[: int(config["lead_character_limit"])]
    weights = config["weights"]
    category_details: dict[str, dict[str, Any]] = {}
    for category, tiers in category_patterns.items():
        tier_hits = {tier: matched(patterns, scored_text) for tier, patterns in tiers.items()}
        lead_hits = {tier: matched(patterns, lead_text) for tier, patterns in tiers.items()}
        score = sum(int(weights[tier]) * len(values) for tier, values in tier_hits.items())
        lead_score = sum(int(weights[tier]) * len(values) for tier, values in lead_hits.items())
        category_details[category] = {
            "score": score,
            "lead_score": lead_score,
            "hits": tier_hits,
        }

    ordered_categories = sorted(
        category_details,
        key=lambda item: (-category_details[item]["score"], item),
    )
    top_category = ordered_categories[0] if ordered_categories else ""
    domain_score = category_details[top_category]["score"] if top_category else 0
    lead_domain_score = max(
        (details["lead_score"] for details in category_details.values()), default=0
    )
    tier_counts = Counter()
    matched_terms: list[str] = []
    for category, details in category_details.items():
        for tier, labels in details["hits"].items():
            tier_counts[tier] += len(labels)
            matched_terms.extend(f"{category}:{tier}:{label}" for label in labels)

    technical_hits = {
        group: matched(patterns, scored_text) for group, patterns in technical_patterns.items()
    }
    technical_group_count = sum(bool(values) for values in technical_hits.values())
    language_hits = matched(language_patterns, scored_text)
    decisive_hits = {
        category: matched(patterns, scored_text)
        for category, patterns in decisive_patterns.items()
    }
    lead_decisive_hits = {
        category: matched(patterns, lead_text)
        for category, patterns in decisive_patterns.items()
    }
    decisive_domain_hit_count = sum(len(values) for values in decisive_hits.values())
    lead_decisive_domain_hit_count = sum(
        len(values) for values in lead_decisive_hits.values()
    )
    screen_score = (
        2 * domain_score
        + int(weights["lead_multiplier"]) * lead_domain_score
        + min(technical_group_count, int(weights["technical_group_cap"]))
    )
    default_eligible = status == "available" and screen_score >= int(config["default_threshold"])

    return {
        "repo_id": repo_id,
        "name": candidate["name"],
        "query_ids": candidate["query_ids"],
        "is_target": int(candidate["is_target"]),
        "readme_status": status,
        "readme_path": str(path) if path else "",
        "readme_bytes": path.stat().st_size if path else 0,
        "description_present": int(bool(description.strip())),
        "top_category": top_category,
        "domain_score": domain_score,
        "lead_domain_score": lead_domain_score,
        "strong_hit_count": tier_counts["strong"],
        "specific_hit_count": tier_counts["specific"],
        "contextual_hit_count": tier_counts["contextual"],
        "categories_with_evidence": sum(
            details["score"] > 0 for details in category_details.values()
        ),
        "technical_group_count": technical_group_count,
        "language_hit_count": len(language_hits),
        "decisive_domain_hit_count": decisive_domain_hit_count,
        "lead_decisive_domain_hit_count": lead_decisive_domain_hit_count,
        "screen_score": screen_score,
        "default_eligible": int(default_eligible),
        "matched_domain_terms": "|".join(sorted(matched_terms)),
        "technical_hits": json.dumps(technical_hits, sort_keys=True, separators=(",", ":")),
        "language_hits": "|".join(language_hits),
        "decisive_domain_hits": "|".join(
            sorted(
                f"{category}:{label}"
                for category, labels in decisive_hits.items()
                for label in labels
            )
        ),
        "lead_decisive_domain_hits": "|".join(
            sorted(
                f"{category}:{label}"
                for category, labels in lead_decisive_hits.items()
                for label in labels
            )
        ),
        "category_scores": json.dumps(
            {category: details["score"] for category, details in category_details.items()},
            sort_keys=True,
            separators=(",", ":"),
        ),
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def threshold_curve(rows: list[dict[str, Any]]) -> list[dict[str, int]]:
    available = [row for row in rows if row["readme_status"] == "available"]
    unavailable = [row for row in rows if row["readme_status"] == "unavailable"]
    curve = []
    for threshold in sorted({int(row["screen_score"]) for row in available}, reverse=True):
        selected_available = [row for row in available if int(row["screen_score"]) >= threshold]
        curve.append(
            {
                "threshold": threshold,
                "selected_available": len(selected_available),
                "retained_unavailable": len(unavailable),
                "selected_processed_total": len(selected_available) + len(unavailable),
                "selected_processed_targets": sum(
                    int(row["is_target"]) for row in selected_available + unavailable
                ),
            }
        )
    return curve


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidates", type=Path, required=True)
    parser.add_argument("--readme-dir", type=Path, action="append", required=True)
    parser.add_argument("--manifest", type=Path, action="append")
    parser.add_argument("--record-dir", type=Path, action="append")
    parser.add_argument("--descriptions", type=Path)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--selected", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    with args.candidates.open(newline="", encoding="utf-8") as handle:
        candidates = list(csv.DictReader(handle))
    manifests = load_jsonl(args.manifest)
    manifests.update(load_record_directories(args.record_dir))
    descriptions = load_descriptions(args.descriptions)
    paths = readme_paths(args.readme_dir)

    category_patterns = {
        category: {tier: compile_map(values) for tier, values in tiers.items()}
        for category, tiers in config["categories"].items()
    }
    technical_patterns = {
        group: compile_map(values) for group, values in config["technical_signals"].items()
    }
    language_patterns = compile_map(config["language_signals"])
    decisive_patterns: dict[str, dict[str, re.Pattern[str]]] = {}
    for category, tiers in config["categories"].items():
        values = dict(tiers["strong"])
        for label in config["promoted_decisive_labels"].get(category, []):
            if label not in tiers["specific"]:
                raise ValueError(f"unknown promoted decisive label for {category}: {label}")
            values[label] = tiers["specific"][label]
        values.update(config["additional_decisive_patterns"].get(category, {}))
        decisive_patterns[category] = compile_map(values)
    rows = [
        feature_row(
            candidate,
            paths.get(int(candidate["repo_id"])),
            manifests.get(int(candidate["repo_id"])),
            descriptions.get(int(candidate["repo_id"]), ""),
            config,
            category_patterns,
            technical_patterns,
            language_patterns,
            decisive_patterns,
        )
        for candidate in candidates
    ]

    statuses = Counter(row["readme_status"] for row in rows)
    target_statuses = Counter(
        row["readme_status"] for row in rows if int(row["is_target"])
    )
    available_targets = [
        row for row in rows if int(row["is_target"]) and row["readme_status"] == "available"
    ]
    calibrated_threshold = min(
        (int(row["screen_score"]) for row in available_targets), default=None
    )
    processed_all_targets = target_statuses["pending"] == 0 and target_statuses["manifest_file_missing"] == 0
    threshold_used = int(config["default_threshold"])
    selected_rows = []
    for row in rows:
        query_ids = set(row["query_ids"].split("|"))
        strata = config["manual_review_query_strata"]
        decisive_selected = (
            row["readme_status"] == "available"
            and int(row["decisive_domain_hit_count"]) > 0
            and int(row["technical_group_count"]) > 0
        )
        short_ambiguous_selected = (
            row["readme_status"] == "available"
            and int(row["domain_score"]) == 0
            and int(row["readme_bytes"])
                <= int(config["manual_review_if_no_domain_and_readme_bytes_at_most"])
            and bool(query_ids & set(strata["short_non_descriptive_readme"]))
        )
        technical_hits = json.loads(row["technical_hits"])
        technical_ambiguous_selected = (
            row["readme_status"] == "available"
            and int(row["domain_score"]) == 0
            and (
                any(
                    label in technical_hits.get("build", [])
                    for label in config["manual_review_no_domain_build_labels"]
                )
                and bool(query_ids & set(strata["cmake_non_descriptive_readme"]))
                or int(row["technical_group_count"])
                    >= int(config["manual_review_no_domain_minimum_technical_groups"])
                and bool(query_ids & set(strata["fully_documented_but_non_descriptive_readme"]))
            )
        )
        unavailable_selected = (
            bool(config["retain_confirmed_readme_unavailable"])
            and row["readme_status"] == "unavailable"
            and bool(query_ids & set(strata["unavailable_readme"]))
        )
        row["selected"] = int(
            decisive_selected
            or short_ambiguous_selected
            or technical_ambiguous_selected
            or unavailable_selected
        )
        row["selection_reason"] = (
            "decisive_domain_and_technical_evidence" if decisive_selected
            else "short_README_without_domain_evidence_manual_review" if short_ambiguous_selected
            else "technical_README_without_domain_evidence_manual_review" if technical_ambiguous_selected
            else "README_unavailable_manual_review" if unavailable_selected
            else "pending" if row["readme_status"] in {"pending", "manifest_file_missing"}
            else "below_threshold"
        )
        if row["selected"]:
            selected_rows.append(row)

    write_csv(args.features, rows)
    write_csv(args.selected, selected_rows)
    curve = threshold_curve(rows)
    report = {
        "version": config["version"],
        "status": "final" if statuses["pending"] == 0 and statuses["manifest_file_missing"] == 0 else "preliminary",
        "candidate_population": len(rows),
        "target_population": sum(int(row["is_target"]) for row in rows),
        "readme_status": dict(sorted(statuses.items())),
        "target_readme_status": dict(sorted(target_statuses.items())),
        "description_records": len(descriptions),
        "default_threshold": int(config["default_threshold"]),
        "calibrated_target_preserving_threshold": calibrated_threshold,
        "all_targets_processed": processed_all_targets,
        "threshold_used": threshold_used,
        "threshold_policy": "reported as a diagnostic only; selection uses decisive domain evidence plus technical evidence and conservative manual-review fallbacks",
        "retain_confirmed_readme_unavailable": bool(config["retain_confirmed_readme_unavailable"]),
        "selected_processed_candidates": len(selected_rows),
        "selected_processed_targets": sum(int(row["is_target"]) for row in selected_rows),
        "pending_candidates_not_classified": statuses["pending"] + statuses["manifest_file_missing"],
        "pending_targets_not_classified": target_statuses["pending"] + target_statuses["manifest_file_missing"],
        "under_1000_on_processed_records": len(selected_rows) < 1000,
        "calibration_disclosure": config["calibration_disclosure"],
        "scored_text_sources": config["scored_text_sources"],
        "excluded_text_sources": config["excluded_text_sources"],
        "threshold_curve": curve,
        "inputs": {
            "candidates": str(args.candidates),
            "readme_dirs": [str(path) for path in args.readme_dir],
            "manifests": [str(path) for path in args.manifest] if args.manifest else [],
            "record_dirs": [str(path) for path in args.record_dir] if args.record_dir else [],
            "descriptions": str(args.descriptions) if args.descriptions else "",
            "config": str(args.config),
            "candidates_sha256": sha256(args.candidates),
            "config_sha256": sha256(args.config)
        },
        "outputs": {
            "features": str(args.features),
            "selected": str(args.selected)
        }
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in (
        "status", "readme_status", "target_readme_status", "threshold_used",
        "selected_processed_candidates", "selected_processed_targets",
        "pending_candidates_not_classified", "pending_targets_not_classified"
    )}, indent=2))


if __name__ == "__main__":
    main()
